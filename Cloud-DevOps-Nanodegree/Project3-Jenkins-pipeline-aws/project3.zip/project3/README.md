# static - jenkins pipeline

Github Link:
https://github.com/abdelrahman403/static

Project Link:
http://udacity-devops-proj3.s3-website.us-east-2.amazonaws.com/index.html

